package com.example.myapplication.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.ArrayList;

import com.example.myapplication.ProductListener;
import com.example.myapplication.ProductsAdapterReccylerview;
import com.example.myapplication.R;
import com.example.myapplication.Utils;
import com.example.myapplication.databinding.ActivityMainBinding;
import com.example.myapplication.db.DBManager;
import com.example.myapplication.model.Cart;
import com.example.myapplication.model.Category;
import com.example.myapplication.model.Product;
import com.example.myapplication.model.Student;

public class MainActivity extends AppCompatActivity implements ProductListener {

    private DBManager db;
    ProductsAdapterReccylerview productsAdapterReccylerview;
    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = new DBManager(this);
        db.open();
        for (Category category : Utils.getCategories()) {
            db.insert(category);
        }
        for (Product product : Utils.getProductList()) {
            db.insert(product);
        }
        ArrayList<Product> productArrayList = db.fetchProducts();
        initAdapter(productArrayList);
        Log.d(MainActivity.class.getSimpleName(), productArrayList.toString());
    }

    private void initAdapter(ArrayList<Product> productArrayList) {
        productsAdapterReccylerview = new ProductsAdapterReccylerview(MainActivity.class.getSimpleName(),productArrayList, this);
        binding.productsRv.setAdapter(productsAdapterReccylerview);
        binding.productsRv.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    public void onAddToCart(int productId, int count) {

        Cart cart = new Cart(productId, count);
        db.insert(cart);
    }

    @Override
    public void deleteProduct(int productId, int pos) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

         switch (item.getItemId()){
             case R.id.item_cart:
                 startActivity(new Intent(getApplicationContext(),CartActivity.class));
                 return true;
         }
         return super.onOptionsItemSelected(item);
    }
}