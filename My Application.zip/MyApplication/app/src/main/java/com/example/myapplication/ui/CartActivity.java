package com.example.myapplication.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;

import com.example.myapplication.ProductListener;
import com.example.myapplication.ProductsAdapterReccylerview;
import com.example.myapplication.R;
import com.example.myapplication.databinding.ActivityCartBinding;
import com.example.myapplication.db.DBManager;
import com.example.myapplication.model.Product;

import java.util.ArrayList;

public class CartActivity extends AppCompatActivity {
    private DBManager db;
    ProductsAdapterReccylerview productsAdapterReccylerview;
    ActivityCartBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        db = new DBManager(this);
        db.open();
        ArrayList<Product> productArrayList = db.fetchCart();
        initAdapter(productArrayList);
    }

    private void initAdapter(ArrayList<Product> productArrayList) {
        productsAdapterReccylerview = new ProductsAdapterReccylerview(CartActivity.class.getSimpleName(), productArrayList, new ProductListener() {
            @Override
            public void onAddToCart(int productId, int count) {

            }

            @Override
            public void deleteProduct(int productId, int pos) {

            }
        });
        binding.productsRv.setAdapter(productsAdapterReccylerview);
        binding.productsRv.setLayoutManager(new LinearLayoutManager(this));
    }
}